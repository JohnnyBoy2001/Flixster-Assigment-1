//
//  MovieGridCell.swift
//  Flixster
//
//  Created by wikiwoo on 9/11/21.
//

import UIKit
import AlamofireImage

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
    
}
